import { Student } from './student.js';

export class StudentList {
    constructor() {
        this.students = [];
        this.failedStudents = [];
    }

    addStudent(name, grade) {
        const student = new Student(name, grade);
        this.students.push(student);
    }

    processStudents() {
        this.failedStudents = this.students.filter(student => student.grade < 7);
        this.students = this.students.filter(student => student.grade >= 7);
    }
}