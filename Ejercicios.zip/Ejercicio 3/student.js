export class Student {
    constructor(name, grade) {
        this.name = name;
        this.grade = grade;
    }
}