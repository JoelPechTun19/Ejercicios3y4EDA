import { StudentList } from './studentList.js';

const studentList = new StudentList();

function displayStudents(list, className) {
    const listElement = document.createElement('ul');
    list.forEach(student => {
        const listItem = document.createElement('li');
        listItem.textContent = `${student.name} - Calificación:${student.grade}`;
        listElement.appendChild(listItem);
    });
    document.body.appendChild(listElement).classList.add(className);
}

function clearDisplay() {
    const elementsToRemove = document.querySelectorAll('ul');
    elementsToRemove.forEach(element => element.remove());
}

// Manejo del formulario
document.addEventListener('DOMContentLoaded', () => {
    const form = document.createElement('form');
    form.innerHTML = `
        <label for="name">Nombre del Alumno:</label>
        <input type="text" id="name" required>
        <label for="grade">Calificación:</label>
        <input type="number" id="grade" required>
        <button type="button" id="submit">Agregar Alumno</button>
        <button type="button" id="showPassed">Mostrar Aprobados</button>
        <button type="button" id="showFailed">Mostrar Reprobados</button>
        <button type="button" id="showAll">Mostrar Todos</button>
    `;
    document.body.appendChild(form);

    const nameInput = document.getElementById('name');
    const gradeInput = document.getElementById('grade');
    const submitButton = document.getElementById('submit');
    const showPassedButton = document.getElementById('showPassed');
    const showFailedButton = document.getElementById('showFailed');
    const showAllButton = document.getElementById('showAll');

    submitButton.addEventListener('click', () => {
        const name = nameInput.value;
        const grade = parseFloat(gradeInput.value);
        if (!isNaN(grade)) {
            studentList.addStudent(name, grade);
            clearDisplay();
            nameInput.value = '';
            gradeInput.value = '';
        }
    });

    showPassedButton.addEventListener('click', () => {
        clearDisplay();
        studentList.processStudents();
        displayStudents(studentList.students, 'passed');
    });

    showFailedButton.addEventListener('click', () => {
        clearDisplay();
        studentList.processStudents();
        displayStudents(studentList.failedStudents, 'failed');
    });

    showAllButton.addEventListener('click', () => {
        clearDisplay();
        displayStudents(studentList.students.concat(studentList.failedStudents), 'all');
    });
});
