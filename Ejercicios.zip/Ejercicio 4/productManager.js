import { Product } from './product.js';

export class ProductManager {
    constructor() {
        this.productList = [];
    }

    isKeyUnique(key) {
        return !this.productList.some(product => product.key === key);
    }

    addProduct(key, name, price) {
        if (this.isKeyUnique(key)) {
            const product = new Product(key, name, price);
            this.productList.push(product);
            this.updateProductList();
        } else {
            alert('Esta clave de producto ya existe, elige otra.');
        }
    }

    deleteProduct(key) {
        this.productList = this.productList.filter(product => product.key !== key);
        this.updateProductList();
    }

    showOrderedProducts() {
        const orderedList = this.productList.slice().sort((a, b) => a.name.localeCompare(b.name));
        this.updateProductList(orderedList);
    }

    showTotalCost() {
        const totalCost = this.productList.reduce((acc, product) => acc + product.price, 0);
        document.getElementById('totalCost').textContent = `Costo Total: $${totalCost.toFixed(2)}`;
    }

    updateProductList(list = this.productList) {
        const productListElement = document.getElementById('productList');
        productListElement.innerHTML = '';

        list.forEach(product => {
            const li = document.createElement('li');
            li.textContent = `${product.key}: ${product.name} - $${product.price.toFixed(2)}`;
            productListElement.appendChild(li);
        });
    }
}
