export class Product {
    constructor(key, name, price) {
        this.key = key;
        this.name = name;
        this.price = price;
    }
}