import { ProductManager } from './productManager.js';

const productManager = new ProductManager();

window.addProduct = () => {
    const productKey = document.getElementById('productKey').value;
    const productName = document.getElementById('productName').value;
    const productPrice = parseFloat(document.getElementById('productPrice').value);

    if (productKey && productName && !isNaN(productPrice)) {
        productManager.addProduct(productKey, productName, productPrice);
    } else {
        alert('Por favor ingrese información válida del producto.');
    }
};

window.deleteProduct = () => {
    const productKey = prompt('Ingrese la clave del producto a eliminar:');
    if (productKey) {
        productManager.deleteProduct(productKey);
    }
};

window.showOrderedProducts = () => {
    productManager.showOrderedProducts();
};

window.showTotalCost = () => {
    productManager.showTotalCost();
};